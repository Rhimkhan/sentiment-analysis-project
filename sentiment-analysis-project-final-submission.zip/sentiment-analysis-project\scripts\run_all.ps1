﻿Write-Host "🚀 Starting All Services..." -ForegroundColor Cyan
Write-Host "=================================" -ForegroundColor Yellow

Write-Host "📊 Starting Streamlit Dashboard..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PWD\src\dashboard'; streamlit run app.py"

Write-Host ""
Write-Host "✅ Services started!" -ForegroundColor Cyan
Write-Host ""
Write-Host "📍 Streamlit: http://localhost:8501" -ForegroundColor Yellow
Write-Host ""
Write-Host "💡 To stop: Press Ctrl+C in each window" -ForegroundColor Red

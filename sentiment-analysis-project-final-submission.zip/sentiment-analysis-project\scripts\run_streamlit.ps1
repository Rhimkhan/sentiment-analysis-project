﻿Write-Host "🚀 Starting Streamlit Dashboard..." -ForegroundColor Cyan
cd "$PWD\src\dashboard"
streamlit run app.py

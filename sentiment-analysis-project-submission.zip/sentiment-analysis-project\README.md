# 🎯 Real-Time Sentiment Analysis Pipeline

> An end-to-end, production-ready sentiment analysis system for internship assignment

## 📊 Project Overview
Complete sentiment analysis pipeline with real-time data processing, NLP analysis, and interactive dashboards.

## 🎯 Key Features
- ✅ Real-time Data Processing with Apache Kafka
- ✅ Advanced NLP with Hugging Face Transformers
- ✅ Interactive Dashboards (Streamlit + Next.js)
- ✅ Admin Control Panel
- ✅ Docker Support
- ✅ Production Ready

## 🛠️ Tech Stack
- Python 3.11+
- Apache Kafka
- Hugging Face Transformers
- Streamlit
- Next.js
- MongoDB
- Redis
- Docker

## 🚀 Quick Start
```bash
git clone https://github.com/yourusername/sentiment-analysis-project.git
cd sentiment-analysis-project
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
.\scripts\run_all.ps1
```

## 📊 Dashboards

- Streamlit: http://localhost:8501
- Next.js: http://localhost:3000
- Admin Login: admin/admin123

## 📄 License
MIT License

## 👨‍💻 Author
Your Name

- GitHub: @yourusername
- LinkedIn: yourlinkedin

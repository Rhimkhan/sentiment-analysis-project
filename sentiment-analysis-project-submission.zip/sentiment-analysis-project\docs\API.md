# API Documentation

## Endpoints

### GET /api/sentiment
Returns latest sentiment analysis results.

**Response:**
```json
{
  "status": "success",
  "data": [
    {
      "text": "I love this product!",
      "sentiment": "POSITIVE",
      "confidence": 0.95,
      "timestamp": "2024-01-01T12:00:00"
    }
  ]
}
```

### POST /api/sentiment
Analyze sentiment of text.

**Request:**

```json
{
  "text": "This is amazing!"
}
```

**Response:**

```json
{
  "sentiment": "POSITIVE",
  "confidence": 0.92,
  "scores": {
    "positive": 0.92,
    "neutral": 0.05,
    "negative": 0.03
  }
}
```

### GET /api/stats
Get aggregated statistics.

**Response:**

```json
{
  "total_posts": 1000,
  "sentiment_counts": {
    "positive": 450,
    "neutral": 300,
    "negative": 250
  }
}
```

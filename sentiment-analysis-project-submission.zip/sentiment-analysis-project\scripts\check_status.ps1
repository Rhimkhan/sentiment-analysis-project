Write-Host "📊 Checking Dashboard Status..." -ForegroundColor Cyan
$streamlit = Get-Process python* -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -like "*streamlit*" }
if ($streamlit) { Write-Host "✅ Streamlit: http://localhost:8501" -ForegroundColor Green } 
else { Write-Host "❌ Streamlit not running" -ForegroundColor Red }
$nextjs = Get-Process node* -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -like "*next*" }
if ($nextjs) { Write-Host "✅ Next.js: http://localhost:3000" -ForegroundColor Green } 
else { Write-Host "❌ Next.js not running" -ForegroundColor Red }

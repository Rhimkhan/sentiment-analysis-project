Write-Host "🚀 Starting All Services..." -ForegroundColor Cyan

# Start Streamlit in a new PowerShell window
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PWD\src\dashboard'; streamlit run app.py"
Start-Sleep -Seconds 2

# Start Next.js in a new PowerShell window (if sentiment-dashboard exists)
if (Test-Path "$PWD\sentiment-dashboard\package.json") {
    Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PWD\sentiment-dashboard'; npm run dev"
} else {
    Write-Host "⚠️ sentiment-dashboard folder not found. Skip Next.js start." -ForegroundColor Yellow
}

Write-Host "✅ All services started (or attempted)." -ForegroundColor Green
Write-Host "📍 Streamlit: http://localhost:8501" -ForegroundColor Yellow
Write-Host "📍 Next.js: http://localhost:3000" -ForegroundColor Yellow

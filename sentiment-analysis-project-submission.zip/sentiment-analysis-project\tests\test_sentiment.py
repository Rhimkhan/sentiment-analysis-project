import pytest
from src.dashboard.app import get_sentiment


def test_sentiment_positive():
    text = "I love this amazing product!"
    sentiment, confidence = get_sentiment(text)
    assert sentiment == "POSITIVE"
    assert confidence > 0.7


def test_sentiment_negative():
    text = "This is the worst service ever!"
    sentiment, confidence = get_sentiment(text)
    assert sentiment == "NEGATIVE"
    assert confidence > 0.7


def test_sentiment_neutral():
    text = "The movie was okay, nothing special."
    sentiment, confidence = get_sentiment(text)
    assert sentiment == "NEUTRAL"
    assert confidence > 0.4


def test_sentiment_edge_case():
    text = ""
    sentiment, confidence = get_sentiment(text)
    assert sentiment == "NEUTRAL"
